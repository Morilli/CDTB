import logging # Change the default logger settings for more information
logging.basicConfig(level='INFO')
from cdragontoolbox.wad import Wad # For the grep_wad function
from cdragontoolbox.hashes import HashGuesser, GameHashGuesser, hashfile_lcu, glob, os, build_wordlist
import string
import signal
unknown_hashes = HashGuesser.unknown_from_export("export")
unknown_hashes -= set(hashfile_lcu.load()) # Remove unnecessary lcu hashes
game_guess = GameHashGuesser(unknown_hashes) # create the instance
wordlist = game_guess.build_wordlist() # create a wordlist
swordlist = build_wordlist(p.rsplit('/', 1)[-1] for p in game_guess.known.values() if any(ext in p for ext in ['.bin'])) # create a special shorter wordlist for higher iteration potential
print(f"Wordlist length: {len(wordlist)} ({len(swordlist)})")
#print(f"Amount of unknown hashes: {len(game_guess.unknown)}")


# Iterate multiple paths; print out missing hashes
#with open("G:/Downloads/Map11LEVELS.wad-Hash-v8.24b-1018.txt") as in_file:
#    myarray = in_file.read().lower().split("\n")
#game_guess.check_iter(f"{a}" for a in myarray)
#for a in myarray:
#    print(a)


extensions = set()
for path in game_guess.known.values():
    _, ext = os.path.splitext(path)
    extensions.add(ext)
ext = list(extensions)
mylist = ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","0","1","2","3","4","5","6","7","8","9","_","-"]
mystring = f"DATA/Levels/Project_ClientLevelScripts/project.manifest"
# print(mystring.lower())
# game_guess.check_iter(f"{mystring.lower()}" for e in extensions)

# game_guess.check_basenames(f"itemgroups{e}" for e in ext)
# shaderlist = ["skinnedmesh", "staticmesh", "addative", "postprocess"]
# game_guess.check_iter(f"data/menu/hud/tftdynamicmenutext.ini" for b in mylist for c in mylist for d in mylist)
# game_guess.substitute_basenames()
# game_guess.substitute_basename_words()
# game_guess.grep_file(r"G:\Downloads\League of Legends.DMP")
# game_guess.grep_wad(Wad(r"G:\Riot Games\PBE\Game\DATA\FINAL\Global.wad.client"))
# game_guess.guess_skin_groups_bin()
# game_guess.guess_skin_groups_bin_using_chromas()
# game_guess.check_basename_prefixes()
# game_guess.substitute_suffixes()
# game_guess.substitute_extensions()
# game_guess.substitute_numbers()
# game_guess.substitute_skin_numbers()
game_guess.substitute_lang()
# game_guess.guess_characters_files()
# game_guess.substitute_character()
# game_guess.add_basename_word()
s = signal.signal(signal.SIGINT, signal.SIG_IGN) # prevent save() interruption
game_guess.save() #save guessed hashes
signal.signal(signal.SIGINT, s)
