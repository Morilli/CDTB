
old_version = "9.23"
current_version = "pbe"

import requests
with open(f"./export/{current_version}.exported.txt", "r") as current_file:
    with open(f"./export/{old_version}.exported.txt", "r") as old_file:
        data = set(current_file.read().split("\n"))
        print(data)
        data -= set(old_file.read().split("\n"))

with open("./output.txt", "w") as out_file:
    out_file.write(f"Files added from version {old_version} to version {current_version}:\n\n")
    for path in sorted(data):
        out_file.write(f"{path}\n")
