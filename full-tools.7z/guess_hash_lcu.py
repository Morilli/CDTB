import logging # Change the default logger settings for more information
logging.basicConfig(level='INFO')
from cdragontoolbox.data import Language, REGIONS
from cdragontoolbox.wad import Wad
from cdragontoolbox.hashes import HashFile, HashGuesser, hashfile_lcu, LcuHashGuesser, hashfile_game, glob, os, build_wordlist
import string
import signal

s = string.ascii_lowercase # For comfortability
unknown_hashes = HashGuesser.unknown_from_export("export")
unknown_hashes -= set(hashfile_game.load()) # Remove unnecessary game hashes
lcu_guess = LcuHashGuesser(unknown_hashes) # create the instance
known_values = list(lcu_guess.known.values())
wordlist = lcu_guess.build_wordlist() # create a wordlist
swordlist = build_wordlist(p.rsplit('/', 1)[-1] for p in known_values if all(ext in p for ext in ['.ogg'])) # create a special shorter wordlist for higher iteration potential
dir_wordlist = build_wordlist(p.rsplit('/', 1)[0] for p in known_values) # create a special dir name wordlist
# print(dir_wordlist)
# with open("G:/Dokumente/Utility Tools/unxxhash/helpers/wordlist.txt", "w+") as out_file: # write wordlist for c++ program
#    for word in sorted(wordlist):
        # out_file.write(f"{word}\n")

print(f"Wordlist length: {len(wordlist)} ({len(swordlist)}, {len(dir_wordlist)})")

mylist = ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","0","1","2","3","4","5","6","7","8","9"]
# Iterate multiple paths; print out missing hashes
extensions = set()
for path in known_values:
    _, ext = os.path.splitext(path)
    extensions.add(ext)
ext = list(extensions)
# print(extensions)
# lcu_guess.check_basenames(f"ability-passive{e}" for e in ext)
# lcu_guess.check_iter(value.replace(f"//", "/") for value in known_values)
lcu_guess.check_iter(f"plugins/rcp-fe-lol-champion-details/global/default/abilit{z}-{a}{b}{c}{d}{e}{f}.png" for f in s for e in s for b in s for c in s for d in s for a in s for z in ["ies", "y"])
# myguess = HashGuesser(hashfile_lcu, unknown_hashes)
# myguess.check_xdbg_hashes(path=r"G:\Dokumente\Utility Tools\x64dbg\release\x32\log-Sa Sep 28 19-26-48 2019.txt")
# lcu_guess.substitute_region_lang()
# lcu_guess.substitute_plugin()
# lcu_guess.substitute_basenames()
# lcu_guess.substitute_basename_words(nold=1, nnew=1)
# lcu_guess.substitute_basename_words(plugin="rcp-fe-lol-champion-details", fileext=".png", words=wordlist, nold=2, nnew=2)
# lcu_guess.add_basename_word()
import timeit
# t = timeit.timeit("lcu_guess.check_basenames(f'{a}.png' for a in lcu_guess.build_wordlist())", "from cdragontoolbox.hashes import HashGuesser, LcuHashGuesser; unknown_hashes = HashGuesser.unknown_from_export(\"export\"); lcu_guess = LcuHashGuesser(unknown_hashes)", number=1)
# t = timeit.timeit("lcu_guess.substitute_basenames()", "from cdragontoolbox.hashes import HashGuesser, LcuHashGuesser; unknown_hashes = HashGuesser.unknown_from_export(\"export\"); lcu_guess = LcuHashGuesser(unknown_hashes)", number=1)
# t = timeit.timeit("lcu_guess.substitute_basename_words()", "from cdragontoolbox.hashes import HashGuesser, LcuHashGuesser; unknown_hashes = HashGuesser.unknown_from_export(\"export\"); lcu_guess = LcuHashGuesser(unknown_hashes)", number=1)
# print(t)
import cProfile
# cProfile.run("lcu_guess.check_basenames(f'{a}.png' for a in swordlist)")
import dis
#dis.dis(HashGuesser._substitute_basename_words)
# lcu_guess.grep_wad(Wad(r"G:\Dokumente\Utility Tools\LeagueDownloader 1.0.2.0\heretest\league_client\releases\0.0.0.21\files\Plugins\rcp-fe-lol-loot\assets.wad"))
# lcu_guess.substitute_numbers()
lcu_guess.guess_patterns()
# lcu_guess.guess_from_game_hashes()
s = signal.signal(signal.SIGINT, signal.SIG_IGN) # prevent save() interruption
lcu_guess.save() #save guessed hashes
signal.signal(signal.SIGINT, s)
