from cdragontoolbox import rstfile
from cdragontoolbox import data
import sys
import requests
import urllib
import re
from multiprocessing.pool import ThreadPool

#print(rstfile.key_to_hash("game_spell_displayname_SummonerDot"))
#exit()
def rstFileFromUrl(url):
    try:
        response = urllib.request.urlopen(urllib.request.Request(url,None,headers))
        return rstfile.RstFile(response)
    except urllib.error.HTTPError:
        pass

def stringsFromUrl(url):
    get = requests.get(url)
    if get.status_code >= 400:
        return
    file_data = get.content.decode()
    # all_matches = pattern.search(file_data)
    # print(f"pattern: \"{pattern}\"")
    # print(pattern.match("tr \"test string here\" = \"whatevr\"").groups())

    # print("here")
    # print(all_matches)
    # exit()
    return pattern.findall(file_data)

# urls = [f"https://raw.communitydragon.org/latest/game/data/menu/fontconfig_{l.value}.txt" for l in data.Language]
# user_agent = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.0.7) Gecko/2009021910 Firefox/3.0.7'
# headers={'User-Agent':user_agent,}
# keys = set()
# getUrls = ThreadPool(10).imap_unordered(rstFileFromUrl, urls)
# for return_value in getUrls:
#     if return_value is not None:
#         keys.update({key for key,_ in return_value.entries.items()})
# print(keys)
# with open("rst.unknown.txt", "w") as out_file:
#     for key in sorted(keys):
#         out_file.write(f"{key:010X}\n")

# known_urls = [f"https://raw.communitydragon.org/9.{minor}/game/data/menu/fontconfig_{l.value}.txt" for l in data.Language for minor in range(23)]
# pattern = re.compile("^tr \"([^\"]*)\" = \"", re.MULTILINE)
# potential_strings = set()
# strings = ThreadPool(10).imap_unordered(stringsFromUrl, known_urls)
# for matches in strings:
#     # print(matches)
#     if matches is not None:
#         potential_strings.update(matches)
# with open("potentialstrings.txt", "w") as out_file:
#     for string in potential_strings:
#         out_file.write(f"{string}\n")


# with open("rst.unknown.txt", "r") as in_file:
#     unknown = {int(line, 16) for line in in_file}
#     # print(unknown)
# with open("potentialstrings.txt", "r") as in_file:
#     potential_strings = {string[:-1] for string in in_file}
# found_strings = {}
# for string in potential_strings:
#     string = string.lower()
#     calculated_key = rstfile.key_to_hash(string)
#     if calculated_key in unknown:
#         found_strings[calculated_key] = string
# with open("hashes.rst.txt", "w") as out_file:
#     for key, string in sorted(found_strings.items(), key=lambda i: i[1]):
#         out_file.write(f"{key:010X} {string}\n")

with open("hashes.rst.txt", "r") as in_file:
    hashes = (l.strip().split(' ', 1) for l in in_file)
    # known_values = {int(h, 16): s for h, s in hashes}
    known_values = {int(h, 16): string for h, string in (line.strip().split(" ", 1) for line in in_file)}
    print(known_values)

parsed_rstfile = rstfile.RstFile(sys.argv[1])
for key in known_values.keys():
    if key in parsed_rstfile.entries:
        parsed_rstfile.entries[known_values[key]] = parsed_rstfile.entries.pop(key)
with open(sys.argv[2], "wb") as out_file:
    out_file.write(bytes(parsed_rstfile.font_config, "utf-8"))

    for key, value in parsed_rstfile.entries.items():
        out_file.write(bytes(f"tr \"{key}\" = \"{value}\"\n", "utf-8"))
