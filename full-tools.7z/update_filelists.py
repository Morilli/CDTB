import requests
from multiprocessing.pool import ThreadPool
import re
import glob
from cdragontoolbox.hashes import hashfile_lcu, hashfile_game

# Download and save all *.filelist.txt files
urls = [(f"./export/{n_season}.{n_patch}.exported.txt", f"https://raw.communitydragon.org/{n_season}.{n_patch}/cdragon/files.exported.txt")
       for n_season in range(7, 11) for n_patch in range(1, 25)]
urls.append(("./export/pbe.exported.txt", "https://raw.communitydragon.org/pbe/cdragon/files.exported.txt"))

def fetch_url(entry):
    path, url = entry
    r = requests.get(url, stream=True)
    if r.status_code == 200:
        with open(path, 'wb+') as f:
            for chunk in r:
                f.write(chunk)
    return

any(ThreadPool(25).imap_unordered(fetch_url, urls))


# Filelists for patch 9.6 and lower aren't up-to-date, so we'll update them here
known_values = {**hashfile_lcu.load(), **hashfile_game.load()}
unknown_line = re.compile(r"^.*/unknown/([0-9a-f]{16})(\..*|)$")
for file in glob.glob("export/*.exported.txt"):
    lines = []
    with open(file, "r") as in_file:
        for line in in_file:
            m = unknown_line.match(line)
            if m:
                if int(m.group(1), 16) in known_values.keys():
                    line = f"{known_values[int(m.group(1), 16)]}\n"
            lines.append(line)
    with open(file, "w") as out_file:
        for line in lines:
            out_file.write(line)
