import logging # Change the default logger settings for more information
logging.basicConfig(level='INFO')
import string
from cdragontoolbox import binfile

with open("G:/Downloads/binHashUnknown.txt") as in_file:
    hashes = in_file.read().split("\n")

unknown_values = sorted(hashes)#{h for h in hashes}
# print(unknown_values)

mylist = ["slime"]
# my_iterator = (f"{a}{b}{c}{d}{e}{f}" for f in string.ascii_lowercase for e in string.ascii_lowercase for d in string.ascii_lowercase for a in string.ascii_lowercase for b in string.ascii_lowercase for c in string.ascii_lowercase)
for mystring in mylist:
    hashvalue = binfile.compute_binhash(mystring)
    print(f"{hashvalue:08X}")
    if f"{hashvalue:08X}" in unknown_values:
        print(f"new: {hashvalue:08X}")
        with open("./found_binhashes.txt", "a+") as out_file:
            out_file.write(mystring + "\n")
# print(f"{hashvalue:08x}")
