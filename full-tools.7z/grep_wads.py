from cdragontoolbox.hashes import HashGuesser, GameHashGuesser, LcuHashGuesser
from cdragontoolbox.wad import Wad
import time
import glob
import signal
import sys
import logging
# logging.basicConfig(level='INFO')
import os

start_time = time.time()

unknown_hashes = HashGuesser.unknown_from_export("export") # Used for hash guessing methods later

print("Started grepping game files.") # Guess game hashes
myguess_game = GameHashGuesser.from_wads([Wad(path) for path in glob.glob("G:/Riot Games/PBE/Game/DATA/FINAL/**/*.wad.client", recursive=True)])
myguess_game.unknown |= unknown_hashes
for wad in myguess_game.wads:
    wad.guess_extensions()
    unknown_before = len(myguess_game.unknown)
    myguess_game.grep_wad(wad)
    found_hashes = unknown_before - len(myguess_game.unknown)
    if found_hashes:
        print(f"found game hashes: {found_hashes}")
unknown_hashes = myguess_game.unknown
s = signal.signal(signal.SIGINT, signal.SIG_IGN) # prevent save() interruption
myguess_game.save() #save guessed game hashes
signal.signal(signal.SIGINT, s)
print("Finished grepping game files.")

print("Started grepping lcu files.") # Guess lcu hashes
myguess_lcu = LcuHashGuesser.from_wads([Wad(path) for path in glob.glob("G:/Riot Games/PBE/Plugins/**/*.wad", recursive=True)])
myguess_lcu.unknown |= unknown_hashes
for wad in myguess_lcu.wads:
    wad.guess_extensions()
    unknown_before = len(myguess_lcu.unknown)
    myguess_lcu.grep_wad(wad)
    found_hashes = unknown_before - len(myguess_lcu.unknown)
    if found_hashes:
        print(f"found lcu hashes: {found_hashes}")
unknown_hashes = myguess_lcu.unknown
s = signal.signal(signal.SIGINT, signal.SIG_IGN) # prevent save() interruption
myguess_lcu.save() #save guessed lcu hashes
signal.signal(signal.SIGINT, s)
print("Finished grepping lcu files.")

print(time.time() - start_time)

with open("./export/all_unknown_hashes.unknown.txt", "w") as out_file:
    for hash in unknown_hashes:
        out_file.write("%016x\n" % hash)

# exit()

# Run some guessing methods
logging.basicConfig(level='INFO')

print("Started guessing game hashes...")
game_guess = GameHashGuesser(unknown_hashes)
game_guess.guess_skin_groups_bin_using_chromas()
game_guess.check_basename_prefixes()
game_guess.substitute_suffixes()
game_guess.substitute_extensions()
game_guess.substitute_numbers()
game_guess.substitute_skin_numbers()
game_guess.substitute_lang()
game_guess.guess_characters_files()
game_guess.substitute_character()
game_guess.guess_shader_variants()
s = signal.signal(signal.SIGINT, signal.SIG_IGN) # prevent save() interruption
game_guess.save()
signal.signal(signal.SIGINT, s)

print("Started guessing lcu hashes...")
lcu_guess = LcuHashGuesser(unknown_hashes)
lcu_guess.substitute_region_lang()
lcu_guess.substitute_plugin()
lcu_guess.substitute_basenames()
lcu_guess.substitute_basename_words()
# lcu_guess.add_basename_word()
lcu_guess.substitute_extensions()
lcu_guess.substitute_numbers()
lcu_guess.guess_patterns()
lcu_guess.guess_from_game_hashes()
s = signal.signal(signal.SIGINT, signal.SIG_IGN) # prevent save() interruption
lcu_guess.save()
signal.signal(signal.SIGINT, s)
